import lib3 from 'lib3.js';

function hash() {
    return lib3.hash();
}

export default {hash};
