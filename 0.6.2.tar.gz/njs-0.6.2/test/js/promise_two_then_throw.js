Promise.resolve()
.then(() => {nonExsistingOne()});

Promise.resolve()
.then(() => {nonExsistingTwo()});